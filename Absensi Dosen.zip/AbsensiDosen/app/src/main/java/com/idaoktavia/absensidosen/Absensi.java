package com.idaoktavia.absensidosen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Absensi extends Activity implements View.OnClickListener {
    Button startButton;
    EditText editText;
    String upc=null;
    //update
    private RequestQueue requestQueue;
    private StringRequest stringRequest;

    ArrayList<HashMap<String, String>> list_data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //jendela tanpa title
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_absensi);
        startButton = (Button) findViewById(R.id.buttonStart);
        startButton.setOnClickListener(this);
        editText = findViewById(R.id.labelCopy);
        Intent intent = getIntent();
        upc = intent.getStringExtra("hasilscan");
        editText.setText(upc);
        String url = "https://presensidosen.000webhostapp.com/login.php?id_karyawan=".concat(String.valueOf(editText.getText()));
        requestQueue = Volley.newRequestQueue(Absensi.this);
        list_data = new ArrayList<HashMap<String, String>>();
        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("karyawan");
//                    for (int a = 0; a < jsonArray.length(); a ++){
//                        JSONObject json = jsonArray.getJSONObject(a);
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
//                        map.put("id", json.getString("id_karyawan"));
//                        map.put("nama", json.getString("nama"));
//                        map.put("alamat", json.getString("alamat"));
//                        map.put("jabatan", json.getString("jabatan"));
//                        list_data.add(map);
//                    }

                    if(jsonArray.length()!=0) {
                        String jab=null;
                            Intent b = new Intent(Absensi.this, Home.class);
                            Intent i = new Intent(Absensi.this, com.idaoktavia.absensidosen.HomeAdmin.class);
                            for (int a = 0; a < jsonArray.length(); a ++){
                                    JSONObject json = jsonArray.getJSONObject(a);
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
                                    i.putExtra("id_karyawan", json.getString("id_karyawan"));
                                    i.putExtra("nama", json.getString("nama"));
                                    i.putExtra("upps", json.getString("upps"));
                                    i.putExtra("jabatan", json.getString("jabatan"));

                                    jab=json.getString("jabatan");

//                        list_data.add(map);
                                 }
                            if(jab.equals("administrator")) {
                                startActivity(i);
                            }else{
                                startActivity(b);
                            }
                        }else{
                            //editText.setText(list_data.get(0).get("id_karyawan"));
                            //Intent j = new Intent(Absensi.this, Absensi.class);
                            //startActivity(j);
                            Toast.makeText(Absensi.this, "Silahkan Coba Lagi", Toast.LENGTH_SHORT).show();
                       }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Absensi.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(stringRequest);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.buttonStart : Intent i = new Intent(this, QRScanner.class);
                startActivity(i);
        }
    }

}