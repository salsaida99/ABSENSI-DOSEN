package com.idaoktavia.absensidosen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.idaoktavia.absensidosen.QRcodeTest.IntentIntegrator;
import com.idaoktavia.absensidosen.QRcodeTest.IntentResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class QRScanner extends Activity {

    public String upc;
    public EditText EditText;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    SharedPreferences sharedpreferences;
    ArrayList<HashMap<String, String>> list_data;
    public static final String privasiUser="sessionControll";
    public String id_kar, nama_kar, alamat, jabatan;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);

        //jendela tanpa title
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        //memulai pemindaian QRCode
        IntentIntegrator.initiateScan(this);

    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {

            case IntentIntegrator.REQUEST_CODE: {
                if (resultCode != RESULT_CANCELED) {
                    IntentResult scanResult = IntentIntegrator.parseActivityResult (requestCode, resultCode, data);
                    // apabila ada hasil dari pemindaian
                    if (scanResult != null) {
                        // ambil isi dari QRCode
                        upc = scanResult.getContents ();
                        String url = "https://presensidosen.000webhostapp.com//login.php?id_karyawan=".concat(String.valueOf(upc));
                        requestQueue = Volley.newRequestQueue(QRScanner.this);
                        list_data = new ArrayList<HashMap<String, String>>();
                        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jsonObject = new JSONObject(response);
                                    JSONArray jsonArray = jsonObject.getJSONArray("karyawan");
//                    for (int a = 0; a < jsonArray.length(); a ++){
//                        JSONObject json = jsonArray.getJSONObject(a);
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
//                        map.put("id", json.getString("id_karyawan"));
//                        map.put("nama", json.getString("nama"));
//                        map.put("alamat", json.getString("alamat"));
//                        map.put("jabatan", json.getString("jabatan"));
//                        list_data.add(map);
//                    }

                                    if(jsonArray.length()!=0) {
                                        Intent i = new Intent(QRScanner.this, com.idaoktavia.absensidosen.Home.class);
                                        Intent b = new Intent(QRScanner.this, com.idaoktavia.absensidosen.HomeAdmin.class);
                                        sharedpreferences = getSharedPreferences(privasiUser, Context.MODE_PRIVATE);
                                        for (int a = 0; a < jsonArray.length(); a ++){
                                            JSONObject json = jsonArray.getJSONObject(a);
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
                                            i.putExtra("id_karyawan", json.getString("id_karyawan"));
                                            i.putExtra("nama", json.getString("nama"));
                                            i.putExtra("upps", json.getString("upps"));
                                            i.putExtra("jabatan", json.getString("jabatan"));
                                            //pembeda
                                            b.putExtra("id_karyawan", json.getString("id_karyawan"));
                                            b.putExtra("nama", json.getString("nama"));
                                            b.putExtra("upps", json.getString("upps"));
                                            b.putExtra("jabatan", json.getString("jabatan"));
                                            jabatan=json.getString("jabatan");
//                        list_data.add(map);
                                            SharedPreferences.Editor userSes = sharedpreferences.edit();

                                            userSes.putString("id_karyawan", json.getString("id_karyawan"));
                                            userSes.putString("nama", json.getString("nama"));
                                            userSes.putString("jabatan", json.getString("jabatan"));
                                            userSes.commit();
                                        }
                                        if(jabatan.equals("administrator")){
                                            startActivity(b);
                                        }else{
                                            startActivity(i);
                                        }
                                    }else{
                                        //editText.setText(list_data.get(0).get("id_karyawan"));
                                        //Intent j = new Intent(Absensi.this, Absensi.class);
                                        //startActivity(j);
                                        Toast.makeText(QRScanner.this, "Silahkan Coba Lagi", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(QRScanner.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                        requestQueue.add(stringRequest);

                        };
                    break;
                }
            }
        }
    }
}
