package com.idaoktavia.absensidosen;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MataKuliah extends Activity{
    public String id_kar, nama_kar, alamat, jabatan, jam,
            weekDay, tgl, deskripsi, waktu, kota, provinsi, kodepos, negara,
            matakuliah, jumlahsks;
    TextView textNamaMatakuliah, textJumlahSKS, textLokasi, textJam, textHari;
    EditText editNamaMatakuliah, editJumlahSKS;
    protected LocationManager locationManager;
    protected LocationListener locationListener;
    List<Address> addresses;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int LOCATION_REQUEST_CODE = 1;
    Button simpan;
    RequestQueue requestQueue;
    Geocoder geocoder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //jendela tanpa title
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_matakuliah);
        textNamaMatakuliah = findViewById(R.id.textMatakuliah);
        textJumlahSKS = findViewById(R.id.textJumlahSKS);
        editNamaMatakuliah=findViewById(R.id.editMatakuliah);
        editJumlahSKS=findViewById(R.id.editJumlahSKS);
        simpan = findViewById(R.id.buttonsimpan);

        Intent intent = getIntent();
        id_kar = intent.getStringExtra("id_karyawan");
        nama_kar = intent.getStringExtra("nama");
        jabatan = intent.getStringExtra("jabatan");
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        clickSimpan();

    }


    public void clickSimpan() {
        simpan = (Button) findViewById(R.id.buttonsimpan);
        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                matakuliah=editNamaMatakuliah.getText().toString();
                jumlahsks=editJumlahSKS.getText().toString();
                input_data();
            }
        });
    }
    void input_data(){
        String url = "https://presensidosen.000webhostapp.com/admin/tambah_matakuliah.php";
        StringRequest response = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Intent i = new Intent(MataKuliah.this, HomeAdmin.class);
                        startActivity(i);
                    }
                },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map <String, String> form = new HashMap<>();
                form.put("nama_matakuliah", matakuliah);
                form.put("sks", jumlahsks);
                return form;
            }
        };
        requestQueue = Volley.newRequestQueue(MataKuliah.this);
        requestQueue.add(response);
    }
}