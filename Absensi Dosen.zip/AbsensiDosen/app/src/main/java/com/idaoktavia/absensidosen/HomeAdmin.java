package com.idaoktavia.absensidosen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class HomeAdmin extends Activity {
    private Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
    public String id_kar, nama_kar, alamat, jabatan, jam, weekDay, tgl, status, waktu, kota, provinsi, kodepos, negara;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;

    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_home2);
        //jendela tanpa title
        sharedpreferences = getSharedPreferences(Login.privasiUser, Context.MODE_PRIVATE);
        jabatan=sharedpreferences.getString("jabatan","Default").toString();
        Toast.makeText(this, jabatan, Toast.LENGTH_SHORT).show();
        clickAbsenMasuk();
        clickTambahKaryawan();
        clickTambahMataKuliah();
        clickTambahJadwal();
        clickLaporanJadwal();
        clickLaporanAbsensiAdmin();
        clickLaporanPerkuliahan();
        clickAbsenPulang();
        clickExit();
        Intent intent = getIntent();
        id_kar = intent.getStringExtra("id_karyawan");
        nama_kar = sharedpreferences.getString("nama","Default").toString();
        jabatan = sharedpreferences.getString("jabatan","Default").toString();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        jam = sdf.format(new Date());

    }
    private void clickAbsenMasuk() {
        btn1 = (Button) findViewById(R.id.button1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeAdmin.this, AbsensiMasuk.class);
                intent1.putExtra("id_karyawan", id_kar);
                intent1.putExtra("tgl",tgl);
                intent1.putExtra("nama", nama_kar);
                intent1.putExtra("jabatan", jabatan);
                HomeAdmin.this.startActivity(intent1);

            }
        });
    }
    private void clickTambahKaryawan() {
        btn2 = (Button) findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat sdfTgl = new SimpleDateFormat("dd-MM-yyy");
                tgl=sdfTgl.format(new Date());
                Intent intent1 = new Intent(HomeAdmin.this, Karyawan.class);
                intent1.putExtra("id_karyawan", id_kar);
                intent1.putExtra("tgl",tgl);
                intent1.putExtra("nama", nama_kar);
                intent1.putExtra("jabatan", jabatan);
                HomeAdmin.this.startActivity(intent1);
            }
        });
    }

    private void clickTambahMataKuliah() {
        btn3 = (Button) findViewById(R.id.button3);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeAdmin.this,
                        MataKuliah.class);
                HomeAdmin.this.startActivity(intent1);
            }
        });
    }
    private void clickTambahJadwal() {
        btn4 = (Button) findViewById(R.id.button4);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeAdmin.this,
                        JadwalKuliah.class);
                HomeAdmin.this.startActivity(intent1);
            }
        });
    }
    private void clickLaporanJadwal() {
        btn5 = (Button) findViewById(R.id.button5);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeAdmin.this,
                        LaporanJadwalAdmin.class);
                HomeAdmin.this.startActivity(intent1);
            }
        });
    }

    private void clickLaporanAbsensiAdmin() {
        btn6 = (Button) findViewById(R.id.button6);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeAdmin.this,
                        LaporanAbsensiAdmin.class);
                HomeAdmin.this.startActivity(intent1);
            }
        });
    }
    private void clickLaporanPerkuliahan() {
        btn7 = (Button) findViewById(R.id.button7);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeAdmin.this,
                        LaporanPerkuliahan.class);
                HomeAdmin.this.startActivity(intent1);
            }
        });
    }
    private void clickAbsenPulang() {
        btn8 = (Button) findViewById(R.id.button8);
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat sdfTgl = new SimpleDateFormat("dd-MM-yyy");
                tgl=sdfTgl.format(new Date());
                Intent intent1 = new Intent(HomeAdmin.this, AbsensiPulang.class);
                intent1.putExtra("id_karyawan", id_kar);
                intent1.putExtra("tgl",tgl);
                intent1.putExtra("nama", nama_kar);
                intent1.putExtra("jabatan", jabatan);
                HomeAdmin.this.startActivity(intent1);
            }
        });
    }

    private void clickExit() {
        btn9 = (Button) findViewById(R.id.button9);
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(HomeAdmin.this);
                builder.setTitle("E-Presensi").setMessage("Apakah Anda Yakin Ingin Keluar?")
                        .setIcon(getResources().getDrawable(R.drawable.ic_diag)).setCancelable(false)
                        .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
//                                Intent exit = new Intent(Intent.ACTION_MAIN);
//                                exit.addCategory(Intent.CATEGORY_HOME);
//                                exit.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                startActivity(exit);
                                //finish();
                                sharedpreferences = getSharedPreferences(Login.privasiUser, Context.MODE_PRIVATE);
                                SharedPreferences.Editor userSes = sharedpreferences.edit();
                                userSes.clear();
                                userSes.commit();
                                finishAffinity();
                            }
                        }).setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                }).show();
            }
        });
    }


}