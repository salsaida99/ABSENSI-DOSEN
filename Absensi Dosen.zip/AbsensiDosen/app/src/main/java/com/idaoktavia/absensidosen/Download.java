package com.idaoktavia.absensidosen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class Download extends Activity {
    WebView webView;
    String url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_download);
        Intent intent = getIntent();
        url = intent.getStringExtra("url");
        webView=findViewById(R.id.webview1);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(url);
        Toast.makeText(Download.this,"Download Started", Toast.LENGTH_LONG).show();
        Intent intent1=new Intent(Download.this, com.idaoktavia.absensidosen.HomeAdmin.class);
        startActivity(intent1);
    }
}