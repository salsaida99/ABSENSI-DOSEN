package com.idaoktavia.absensidosen;

public class DataJadwalDosen {
    String id_kar, nama_kar, nama_matkul, jumlah_sks,
            hari, jam, semester;
    public DataJadwalDosen(String id_kar, String nama_kar, String nama_matkul, String jumlah_sks,
                       String hari, String jam, String semester){
        this.id_kar=id_kar;
        this.nama_kar=nama_kar;
        this.nama_matkul=nama_matkul;
        this.jumlah_sks=jumlah_sks;
        this.hari=hari;
        this.jam=jam;
        this.semester=semester;
    }
    //    public DataLaporan(String id_kar, String nama_kar, String tgl, String keterangan,
//                       String jam_masuk, String lokasi_mas, String lokasi_pul,
//                       String deskripsi, String jam_pulang){
//                    this.id_kar=id_kar;
//                    this.nama_kar=nama_kar;
//                    this.tgl=tgl;
//                    this.keterangan=keterangan;
//                    this.jam_masuk=jam_masuk;
//                    this.lokasi_mas=lokasi_mas;
//                    this.lokasi_pul=lokasi_pul;
//                    this.deskripsi=deskripsi;
//                    this.jam_pulang=jam_pulang;
//    }
    public String getId_kar(){
        return id_kar;
    }
    public String getNama_kar(){
        return nama_kar;
    }
    public String getNama_matkul(){return nama_matkul;}
    public String getJumlah_sks(){return jumlah_sks;}
    public String getHari(){ return hari;}
    public String getJam(){ return jam;}
    public String getSemester(){return semester;}

}
