package com.idaoktavia.absensidosen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

import androidx.annotation.Nullable;



public class SplashScreen extends Activity {
    //Set waktu lama splashscreen
   // private static int splashInterval = 2000;
    private static final int SPLASH_SCREEN_DURATION = 3000;
    private Handler myHandler;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        this.requestWindowFeature (Window.FEATURE_NO_TITLE);
//        getWindow ().setFlags (WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView (R.layout.activity_splash_screen);

                    myHandler = new Handler();
                    myHandler.postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            // TODO Auto-generated method stub

                            finish();
                            Intent intent = new Intent(SplashScreen.this, Absensi.class);
                            SplashScreen.this.startActivity(intent);

                        }
                    }, SPLASH_SCREEN_DURATION);

    }
}
