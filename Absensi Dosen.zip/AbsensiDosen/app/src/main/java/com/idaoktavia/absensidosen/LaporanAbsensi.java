package com.idaoktavia.absensidosen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class LaporanAbsensi extends Activity {
    public String id_kar, nama_kar, alamat, jabatan, jam, weekDay, tgl, keterangan,
            waktu, kota, provinsi, kodepos, negara, jam_masuk, lokasi_mas, lokasi_pul,
            deskripsi, jam_pulang;
    TextView textJabatan, textLokasi, textJam, textHari;
    ArrayList<DataLaporan> list;
    ListView listView;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    ArrayList<HashMap<String, String>> list_data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_laporanabsensi);
//        textNama = findViewById(R.id.textNamaKaryawan);
//        textJabatan = findViewById(R.id.textJabatanKaryawan);
//        textLokasi = findViewById(R.id.textView3);
//        textJam = findViewById(R.id.textView4);
//        textHari = findViewById(R.id.textView2);
        listView = findViewById(R.id.listview1);
        Intent intent = getIntent();
        id_kar = intent.getStringExtra("id_karyawan");
        nama_kar = intent.getStringExtra("nama");
        jabatan = intent.getStringExtra("jabatan");
        keterangan = intent.getStringExtra("keterangan");
        tgl = intent.getStringExtra("tgl");
        jam_masuk = intent.getStringExtra("jam_masuk");
        lokasi_mas = intent.getStringExtra("lokasi_mas");
        deskripsi = intent.getStringExtra("desk ripsi");
        jam_pulang = intent.getStringExtra("jam_pulang");
        lokasi_pul = intent.getStringExtra("lokasi_pul");
        //textNama.setText("Nama: " + nama_kar);
        //textJabatan.setText("Jabatan: " + jabatan);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        jam = sdf.format(new Date());
        tgl = sdf.format(new Date());
        //textJam.setText("Tanggal : " + id_kar+" "+nama_kar+" "+keterangan+" "+jam_masuk+" "+
        //lokasi_mas+" "+deskripsi+" "+jam_pulang+" "+lokasi_pul);
        //textHari.setText("Hari : " + weekDay);

//        Toast.makeText(LaporanAbsensi.this, url, Toast.LENGTH_SHORT).show();
        //Toast.makeText(LaporanAbsensi.this, keterangan, Toast.LENGTH_SHORT).show();
        tampilkanLaporan();
    }

    private void tampilkanLaporan() {
        list = new ArrayList<>();
        String url = "https://presensidosen.000webhostapp.com/dosen/laporan.php?check="+id_kar;
        RequestQueue requestQueue = Volley.newRequestQueue(LaporanAbsensi.this);
        list_data = new ArrayList<HashMap<String, String>>();
        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("laporan");
//                    for (int a = 0; a < jsonArray.length(); a ++){
//                        JSONObject json = jsonArray.getJSONObject(a);
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
//                        map.put("id", json.getString("id_karyawan"));
//                        map.put("nama", json.getString("nama"));
//                        map.put("alamat", json.getString("alamat"));
//                        map.put("jabatan", json.getString("jabatan"));
//                        list_data.add(map);
//                    }

                    for (int a = 0; a < jsonArray.length(); a++) {
                        JSONObject json = jsonArray.getJSONObject(a);
                        id_kar = json.getString("id_karyawan");
                        nama_kar = json.getString("nama");
                        keterangan = json.getString("keterangan");
                        jam_masuk = json.getString("log_masuk");
                        tgl = json.getString("tanggal_absen");
                        jam_pulang= json.getString("log_pulang");
                        list.add(new DataLaporan(id_kar, nama_kar, tgl, keterangan, jam_masuk, jam_pulang));
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
//                            i.putExtra("id_karyawan", json.getString("id_karyawan"));
//                            i.putExtra("nama", json.getString("nama"));
//                            i.putExtra("keterangan", json.getString("keterangan"));
//                            i.putExtra("tanggal", json.getString("tanggal_absen"));
//                            i.putExtra("jam_masuk", json.getString("jam_absen"));
//                            i.putExtra("lokasi_mas", json.getString("lokasi_masuk"));
//                            i.putExtra("deskripsi", json.getString("deskripsi_kegiatan"));
//                            i.putExtra("jam_pulang", json.getString("jam_pulang"));
//                            i.putExtra("lokasi_pul", json.getString("lokasi_pulang"));

//                        list_data.add(map);
                    }
                    Adapter adapter = new Adapter(LaporanAbsensi.this, list);
                    listView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LaporanAbsensi.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(stringRequest);
    }

}

class Adapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    ArrayList<DataLaporan>model;
    public Adapter(Context context, ArrayList<DataLaporan>model){
        inflater=LayoutInflater.from(context);
        this.context=context;
        this.model=model;
    }

    @Override
    public int getCount() {
        return model.size();
    }

    @Override
    public Object getItem(int position) {
        return model.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    TextView id_kar, nama, keterangan, tanggal;
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view=inflater.inflate(R.layout.list_data, parent, false);
        nama=view.findViewById(R.id.namaKaryawan);
        keterangan=view.findViewById(R.id.statusHadir);
        tanggal=view.findViewById(R.id.tanggalAbsen);

        nama.setText(model.get(position).getNama_kar());
        keterangan.setText(model.get(position).getKeterangan());
        tanggal.setText(model.get(position).getTgl());
        return view;
    }
}
