package com.idaoktavia.absensidosen;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class LaporanAbsensiAdmin extends Activity {
    private static final int REQUEST_PERMISSION_CODE = 100;
    public String id_kar, nama_kar, alamat, jabatan, jam, weekDay, tgl, keterangan,
            waktu, kota, provinsi, kodepos, negara, jam_masuk, lokasi_mas, lokasi_pul,
            deskripsi, jam_pulang, tgl1, tgl2;
    TextView textNama, textJabatan, textLokasi, textJam, textHari;
    ArrayList<DataLaporan> list;
    ListView listView;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    ArrayList<HashMap<String, String>> list_data;
    Button btndownload, btDatePicker1, btDatePicker2;
    private DatePickerDialog datePickerDialog, datePickerDialog2;
    private SimpleDateFormat dateFormatter;
    private TextView tvDateResult1, tvDateResult2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_laporan_admin);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_PERMISSION_CODE);
            }
        }
        Intent intent = getIntent();
        id_kar = intent.getStringExtra("id_karyawan");
        nama_kar = intent.getStringExtra("nama");
        jabatan = intent.getStringExtra("jabatan");
        keterangan = intent.getStringExtra("keterangan");
        tgl = intent.getStringExtra("tanggal");
        jam_masuk = intent.getStringExtra("jam_masuk");
        lokasi_mas=intent.getStringExtra("lokasi_mas");
        deskripsi=intent.getStringExtra("desk ripsi");
        jam_pulang=intent.getStringExtra("jam_pulang");
        lokasi_pul=intent.getStringExtra("lokasi_pul");
        //textNama.setText("Nama: " + nama_kar);
        //textJabatan.setText("Jabatan: " + jabatan);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy", Locale.US);
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        jam = sdf.format(new Date());
        //textJam.setText("Tanggal : " + id_kar+" "+nama_kar+" "+keterangan+" "+jam_masuk+" "+
                //lokasi_mas+" "+deskripsi+" "+jam_pulang+" "+lokasi_pul);
        //textHari.setText("Hari : " + weekDay);

        //tampilkanLaporan();
        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        tvDateResult1 = (TextView) findViewById(R.id.tv_dateresult1);
        tvDateResult2 = (TextView) findViewById(R.id.tv_dateresult2);
        btDatePicker1 = (Button) findViewById(R.id.bt_datepicker1);
        btDatePicker2 = (Button) findViewById(R.id.bt_datepicker2);
        btndownload=(Button) findViewById(R.id.btdownload);
        btDatePicker1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDateDialog();
            }
        });
        btDatePicker2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDateDialog2();
            }
        });

        btndownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tgl1=tvDateResult1.getText().toString();
                tgl2=tvDateResult2.getText().toString();
                String url = "https://presensidosen.000webhostapp.com/admin/lapberkala.php?check=\""+tgl1+"\"&&check2=\""+tgl2+"\"";
                DownloadManager.Request requestFile= new DownloadManager.Request(Uri.parse(url));
                requestFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE|DownloadManager.Request.NETWORK_WIFI);
                requestFile.setTitle("Download");
                requestFile.setDescription("Download File Laporan Absensi ...");
                String outputFileName="Laporan "+tgl1+" sampai "+tgl2+".xls";
                requestFile.setMimeType("application/xls");
                requestFile.allowScanningByMediaScanner();
                requestFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, outputFileName);
                requestFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                downloadManager.enqueue(requestFile);

                Toast.makeText(LaporanAbsensiAdmin.this, "Download Laporan "+tgl1+" - "+tgl2, Toast.LENGTH_LONG).show();

                    Intent intent1 = new Intent(LaporanAbsensiAdmin.this,
                            Download.class);
                    intent1.putExtra("url",url);
                    LaporanAbsensiAdmin.this.startActivity(intent1);

            }
        });

    }



    private void showDateDialog(){

        /**
         * Calendar untuk mendapatkan tanggal sekarang
         */
        Calendar newCalendar = Calendar.getInstance();

        /**
         * Initiate DatePicker dialog
         */
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                /**
                 * Method ini dipanggil saat kita selesai memilih tanggal di DatePicker
                 */

                /**
                 * Set Calendar untuk menampung tanggal yang dipilih
                 */
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);

                /**
                 * Update TextView dengan tanggal yang kita pilih
                 */
                tvDateResult1.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        /**
         * Tampilkan DatePicker dialog
         */
        datePickerDialog.show();
    }

    private void showDateDialog2(){

        /**
         * Calendar untuk mendapatkan tanggal sekarang
         */
        Calendar newCalendar = Calendar.getInstance();

        /**
         * Initiate DatePicker dialog
         */
        datePickerDialog2 = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                /**
                 * Method ini dipanggil saat kita selesai memilih tanggal di DatePicker
                 */

                /**
                 * Set Calendar untuk menampung tanggal yang dipilih
                 */
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);

                /**
                 * Update TextView dengan tanggal yang kita pilih
                 */
                tvDateResult2.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        /**
         * Tampilkan DatePicker dialog
         */
        datePickerDialog2.show();
    }

}

class AdapterAdmin extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    ArrayList<DataLaporan>model;
    public AdapterAdmin(Context context, ArrayList<DataLaporan>model){
        inflater=LayoutInflater.from(context);
        this.context=context;
        this.model=model;
    }

    @Override
    public int getCount() {
        return model.size();
    }

    @Override
    public Object getItem(int position) {
        return model.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    TextView id_kar, nama, keterangan, jam_masuk,deskripsi_kerja;
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view=inflater.inflate(R.layout.list_data, parent, false);
        nama=view.findViewById(R.id.textNamaKaryawan);
        keterangan=view.findViewById(R.id.textKeterangan);
        id_kar.setText("Nomor Pegawai: "+model.get(position).getId_kar());
        nama.setText(model.get(position).getNama_kar());
        keterangan.setText("Status Kehadiran: "+model.get(position).getKeterangan());
        jam_masuk.setText("Masuk Jam: "+model.get(position).getJam_masuk());
        return view;
    }
}
