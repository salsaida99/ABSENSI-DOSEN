package com.idaoktavia.absensidosen;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AbsensiPulang extends Activity{
    public String id_kar, nama_kar, alamat, jabatan, jam, weekDay, tgl, deskripsi, waktu, kota, provinsi, kodepos, negara;
    TextView textNama, textJabatan, textLokasi, textJam, textHari;
    EditText kegiatanKerja;
    protected LocationManager locationManager;
    protected LocationListener locationListener;
    List<Address> addresses;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int LOCATION_REQUEST_CODE = 1;
    Button simpan;
    RequestQueue requestQueue;
    Geocoder geocoder;
    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //jendela tanpa title
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_absensipulang);
        sharedpreferences = getSharedPreferences(Login.privasiUser, Context.MODE_PRIVATE);
        id_kar=sharedpreferences.getString("id_karyawan","Default").toString();

        textNama = findViewById(R.id.textNamaKaryawan);
        textJabatan = findViewById(R.id.textJabatanKaryawan);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(AbsensiPulang.this);
        textLokasi = findViewById(R.id.textView3);
        textJam = findViewById(R.id.textView4);
        textHari = findViewById(R.id.textView2);
        simpan = findViewById(R.id.buttonsimpan);
//        kegiatanKerja = findViewById(R.id.kegiatanKerja);

        nama_kar = sharedpreferences.getString("nama","Default").toString();
        jabatan = sharedpreferences.getString("jabatan","Default").toString();
        textNama.setText("Nama: " + nama_kar);
        textJabatan.setText("Jabatan: " + jabatan);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        jam = sdf.format(new Date());
        textJam.setText("Tanggal : " + jam);
        textHari.setText("Hari : " + weekDay);
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(AbsensiPulang.this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);

        } else {
            getCurrentLocation();
        }
        textLokasi.setText("Lokasi Absen: "+kota);
        clickSimpan();

    }
    @SuppressLint("MissingPermission")
    private void getCurrentLocation() {
        LocationRequest locationRequest=new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(2000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationServices.getFusedLocationProviderClient(AbsensiPulang.this).
                requestLocationUpdates( locationRequest, new LocationCallback(){
                    @Override
                    public void onLocationResult(@NonNull @NotNull LocationResult locationResult) {
                        super.onLocationResult(locationResult);
                        LocationServices.getFusedLocationProviderClient(AbsensiPulang.this)
                                .removeLocationUpdates(this);
                        if(locationResult!=null && locationResult.getLocations().size()>0){
                            int latestLocationIndex=locationResult.getLocations().size()-1;
                            double latitude=locationResult.getLocations().get(latestLocationIndex).getLatitude();
                            double longitude=locationResult.getLocations().get(latestLocationIndex).getLongitude();
                            //textLokasi.setText("Lokasi Absen: "+ String.format(latitude+" "+longitude));
                            geocoder= new Geocoder(AbsensiPulang.this, Locale.getDefault());
                            try {
                                addresses = geocoder.getFromLocation(latitude, longitude, 1);
                                alamat = addresses.get(0).getAddressLine(0);
                                kota = addresses.get(0).getLocality();
                                provinsi = addresses.get(0).getAdminArea();
                                negara = addresses.get(0).getCountryName();
                                kodepos = addresses.get(0).getPostalCode();
                                //knonName = addresses.get(0).getFeatureName();
                                textLokasi.setText("Lokasi Absen: "+kota);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, Looper.getMainLooper());
    }

    private void askLocationPermission() {
        if (ActivityCompat.checkSelfPermission(AbsensiPulang.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(AbsensiPulang.this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(AbsensiPulang.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(AbsensiPulang.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                getCurrentLocation();
            } else {
                //Permission not granted
            }
        }
    }

    public void clickSimpan() {
        simpan = (Button) findViewById(R.id.buttonsimpan);
        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_data();
            }
        });
    }
    void input_data(){
        String url = "https://presensidosen.000webhostapp.com/absen_pulang.php";
        StringRequest response = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Intent i = new Intent(AbsensiPulang.this, Home.class);
                        Intent b = new Intent(AbsensiPulang.this, HomeAdmin.class);
                        if(jabatan.equals("administrator")){
                            startActivity(b);
                        }else{
                            startActivity(i);
                        }
                    }
                },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                SimpleDateFormat sdfTgl = new SimpleDateFormat("dd-MM-yyy");
                tgl=sdfTgl.format(new Date());
                SimpleDateFormat sdfJam = new SimpleDateFormat("HH:mm:ss z");
                waktu=sdfJam.format(new Date());
                //deskripsi=kegiatanKerja.getText().toString();
                Map <String, String> form = new HashMap<>();
                form.put("id_karyawan", id_kar);
                form.put("tgl", tgl);
                form.put("jam", waktu);
                form.put("lokasi",kota);
                //form.put("deskripsi",deskripsi);
                return form;
            }
        };
        requestQueue = Volley.newRequestQueue(AbsensiPulang.this);
        requestQueue.add(response);
    }
}