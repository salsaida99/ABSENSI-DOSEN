package com.idaoktavia.absensidosen;

public class DataLaporan {
    String id_kar, nama_kar, tgl, keterangan,
            jam_masuk, lokasi_mas, lokasi_pul,
            jam_pulang;
    public DataLaporan(String id_kar, String nama_kar, String tgl, String keterangan,
                       String jam_masuk, String jam_pulang){
        this.id_kar=id_kar;
        this.nama_kar=nama_kar;
        this.tgl=tgl;
        this.keterangan=keterangan;
        this.jam_masuk=jam_masuk;
        this.jam_pulang=jam_pulang;
    }
//    public DataLaporan(String id_kar, String nama_kar, String tgl, String keterangan,
//                       String jam_masuk, String lokasi_mas, String lokasi_pul,
//                       String deskripsi, String jam_pulang){
//                    this.id_kar=id_kar;
//                    this.nama_kar=nama_kar;
//                    this.tgl=tgl;
//                    this.keterangan=keterangan;
//                    this.jam_masuk=jam_masuk;
//                    this.lokasi_mas=lokasi_mas;
//                    this.lokasi_pul=lokasi_pul;
//                    this.deskripsi=deskripsi;
//                    this.jam_pulang=jam_pulang;
//    }
    public String getId_kar(){
        return id_kar;
    }
    public String getNama_kar(){
        return nama_kar;
    }
    public String getTgl(){
        return tgl;
    }
    public String getKeterangan(){
        return keterangan;
    }
    public String getJam_masuk(){
        return jam_masuk;
    }
    public String getLokasi_mas(){
        return lokasi_mas;
    }
    public String getLokasi_pul(){
        return lokasi_pul;
    }
    public String getJam_pulang(){
        return jam_pulang;
    }

}
