package com.idaoktavia.absensidosen;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Perkuliahan extends Activity{
    public String id_kar, nama_kar, id_matkul, jam_kuliah, semester, alamat, jabatan, jam, weekDay, tgl,
            deskripsi, waktu, kota, provinsi, kodepos, negara;
    TextView textNama, textMatakuliah, textJam, textHari;
    EditText editKeterangan;
    protected LocationManager locationManager;
    protected LocationListener locationListener;
    List<Address> addresses;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int LOCATION_REQUEST_CODE = 1;
    Button simpan;
    RequestQueue requestQueue;
    Geocoder geocoder;
    public Spinner spinnerMatakuliah, spinnerJamkul, spinnerSemester;
    ArrayList<String> matakuliahList = new ArrayList<>();
    ArrayAdapter<String> matakuliahAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //jendela tanpa title
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_perkuliahan);

        textNama = findViewById(R.id.textNamaKaryawan);
        textMatakuliah = findViewById(R.id.textMatakuliah);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(Perkuliahan.this);
        textJam = findViewById(R.id.textView4);
        textHari = findViewById(R.id.textView2);
        editKeterangan=findViewById(R.id.textKeterangan);
        simpan = findViewById(R.id.buttonsimpan);

        Intent intent = getIntent();
        id_kar = intent.getStringExtra("id_karyawan");
        nama_kar = intent.getStringExtra("nama");
        jabatan = intent.getStringExtra("jabatan");
        tgl = intent.getStringExtra("tgl");
        textNama.setText("Nama Dosen Pengampu: " + nama_kar);
        textMatakuliah.setText("Matakuliah: ");
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        jam = sdf.format(new Date());

        spinnerMatakuliah = findViewById(R.id.pilihMatakuliah);
        ArrayAdapter<String> adapterMatkul = new ArrayAdapter<String>(Perkuliahan.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.matkul));
        adapterMatkul.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMatakuliah.setAdapter(adapterMatkul);
        spinnerMatakuliah.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                id_matkul=String.valueOf(adapterView.getSelectedItemId());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerJamkul = (Spinner) findViewById(R.id.pilihJam);
        ArrayAdapter<String> adapterJamkul = new ArrayAdapter<String>(Perkuliahan.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.jamkul));
        adapterJamkul.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerJamkul.setAdapter(adapterJamkul);
        spinnerJamkul.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                jam_kuliah=adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerSemester = (Spinner) findViewById(R.id.pilihSemester);
        ArrayAdapter<String> adapterSemester = new ArrayAdapter<String>(Perkuliahan.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.semester));
        adapterSemester.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSemester.setAdapter(adapterSemester);
        spinnerSemester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                semester=adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        textJam.setText("Tanggal : " + jam);
        textHari.setText("Hari : " + weekDay);
        clickSimpan();
    }


    public void clickSimpan() {
        simpan = (Button) findViewById(R.id.buttonsimpan);
        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_data();
            }
        });
    }
    void input_data(){
        String url = "https://presensidosen.000webhostapp.com/dosen/tambah_detailperkuliahan.php";
        StringRequest response = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Intent i = new Intent(Perkuliahan.this, Home.class);
                        startActivity(i);
                    }
                },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                SimpleDateFormat sdfTgl = new SimpleDateFormat("dd-MM-yyy");
                tgl=sdfTgl.format(new Date());
                SimpleDateFormat sdfJam = new SimpleDateFormat("HH:mm:ss z");
                waktu=sdfJam.format(new Date());
                deskripsi=editKeterangan.getText().toString();
                Map <String, String> form = new HashMap<>();
                form.put("id_karyawan", id_kar);
                form.put("id_matkul", id_matkul);
                form.put("tgl", tgl);
                form.put("jam", jam_kuliah);
                form.put("semester",semester);
                form.put("deskripsi",deskripsi);
                return form;
            }
        };
        requestQueue = Volley.newRequestQueue(Perkuliahan.this);
        requestQueue.add(response);
    }
}