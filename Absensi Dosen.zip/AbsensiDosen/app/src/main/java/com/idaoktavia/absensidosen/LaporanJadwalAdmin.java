package com.idaoktavia.absensidosen;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class LaporanJadwalAdmin extends Activity {
    public String id_kar, nama_kar, alamat, jabatan, jam, weekDay, tgl, keterangan,
            waktu, kota, provinsi, kodepos, negara, jam_masuk, lokasi_mas, lokasi_pul,
            deskripsi, jam_pulang, nama_matakuliah, semester, hari, jumlah_sks;
    TextView textNama, textJabatan, textLokasi, textJam, textHari;
    ArrayList<DataJadwalDosen> list;
    ListView listView;
    StringRequest stringRequest;
    ArrayList<HashMap<String, String>> list_data_jadwal;
    Button btndownload;
    Spinner spinnerSemester;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_laporanadmin_jadwaldosen);
//        textNama = findViewById(R.id.textNamaKaryawan);
//        textJabatan = findViewById(R.id.textJabatanKaryawan);
//        textLokasi = findViewById(R.id.textView3);
//        textJam = findViewById(R.id.textView4);
//        textHari = findViewById(R.id.textView2);
        listView = findViewById(R.id.listview1);
        Intent intent = getIntent();
        id_kar = intent.getStringExtra("id_karyawan");
        nama_kar = intent.getStringExtra("nama");
        jabatan = intent.getStringExtra("jabatan");
        keterangan = intent.getStringExtra("keterangan");
        tgl = intent.getStringExtra("tanggal");
        jam_masuk = intent.getStringExtra("jam_masuk");
        lokasi_mas = intent.getStringExtra("lokasi_mas");
        deskripsi = intent.getStringExtra("desk ripsi");
        jam_pulang = intent.getStringExtra("jam_pulang");
        lokasi_pul = intent.getStringExtra("lokasi_pul");
        //textNama.setText("Nama: " + nama_kar);
        //textJabatan.setText("Jabatan: " + jabatan);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        jam = sdf.format(new Date());
        tgl = sdf.format(new Date());
        //textJam.setText("Tanggal : " + id_kar+" "+nama_kar+" "+keterangan+" "+jam_masuk+" "+
        //lokasi_mas+" "+deskripsi+" "+jam_pulang+" "+lokasi_pul);
        //textHari.setText("Hari : " + weekDay);

//        Toast.makeText(LaporanAbsensi.this, url, Toast.LENGTH_SHORT).show();
        //Toast.makeText(LaporanAbsensi.this, keterangan, Toast.LENGTH_SHORT).show();
        spinnerSemester = (Spinner) findViewById(R.id.pilihSemester);
        ArrayAdapter<String> adapterSemester = new ArrayAdapter<String>(LaporanJadwalAdmin.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.semester));
        adapterSemester.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSemester.setAdapter(adapterSemester);
        spinnerSemester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                semester=adapterView.getSelectedItem().toString();
                tampilkanLaporan();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btndownload=(Button) findViewById(R.id.btdownload);
        btndownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://presensidosen.000webhostapp.com/admin/laporan_jadwaldosen.php?check="+semester;
                DownloadManager.Request requestFile= new DownloadManager.Request(Uri.parse(url));
                requestFile.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE|DownloadManager.Request.NETWORK_WIFI);
                requestFile.setTitle("Download");
                requestFile.setDescription("Download File Laporan Absensi ...");
                String outputFileName="Laporan Jadwal Semester"+semester+".xls";
                requestFile.setMimeType("application/xls");
                requestFile.allowScanningByMediaScanner();
                requestFile.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, outputFileName);
                requestFile.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                downloadManager.enqueue(requestFile);

                Toast.makeText(LaporanJadwalAdmin.this, "Download Laporan Jadwal Semester"+semester, Toast.LENGTH_LONG).show();

                Intent intent1 = new Intent(LaporanJadwalAdmin.this,
                        Download.class);
                intent1.putExtra("url",url);
                LaporanJadwalAdmin.this.startActivity(intent1);

            }
        });
    }

    private void tampilkanLaporan() {
        list = new ArrayList<>();
        String url2 = "https://presensidosen.000webhostapp.com/admin/laporan_jadwaldosen.php?check="+semester;
        RequestQueue requestQueue2 = Volley.newRequestQueue(LaporanJadwalAdmin.this);
        list_data_jadwal = new ArrayList<HashMap<String, String>>();
        stringRequest = new StringRequest(Request.Method.GET, url2, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("jadwal_dosen");
//                    for (int a = 0; a < jsonArray.length(); a ++){
//                        JSONObject json = jsonArray.getJSONObject(a);
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
//                        map.put("id", json.getString("id_karyawan"));
//                        map.put("nama", json.getString("nama"));
//                        map.put("alamat", json.getString("alamat"));
//                        map.put("jabatan", json.getString("jabatan"));
//                        list_data.add(map);
//                    }

                    for (int a = 0; a < jsonArray.length(); a++) {
                        JSONObject json = jsonArray.getJSONObject(a);
                        id_kar = json.getString("id_karyawan");
                        nama_kar = json.getString("nama");
                        nama_matakuliah = json.getString("nama_matakuliah");
                        jumlah_sks = json.getString("jumlah_sks");
                        hari = json.getString("hari");
                        jam=json.getString("jam");
                        semester=json.getString("semester");
                        list.add(new DataJadwalDosen(id_kar, nama_kar, nama_matakuliah, jumlah_sks, hari, jam, semester));
//                        HashMap<String, String> map  = new HashMap<String, String>();
//                        //get string kanan nama kolom database
//                            i.putExtra("id_karyawan", json.getString("id_karyawan"));
//                            i.putExtra("nama", json.getString("nama"));
//                            i.putExtra("keterangan", json.getString("keterangan"));
//                            i.putExtra("tanggal", json.getString("tanggal_absen"));
//                            i.putExtra("jam_masuk", json.getString("jam_absen"));
//                            i.putExtra("lokasi_mas", json.getString("lokasi_masuk"));
//                            i.putExtra("deskripsi", json.getString("deskripsi_kegiatan"));
//                            i.putExtra("jam_pulang", json.getString("jam_pulang"));
//                            i.putExtra("lokasi_pul", json.getString("lokasi_pulang"));

//                        list_data.add(map);
                    }
                    AdapterJadwalAdmin adapterjadwal = new AdapterJadwalAdmin(LaporanJadwalAdmin.this, list);
                    listView.setAdapter(adapterjadwal);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LaporanJadwalAdmin.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue2.add(stringRequest);
    }

}

class AdapterJadwalAdmin extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    ArrayList<DataJadwalDosen>model;
    public AdapterJadwalAdmin(Context context, ArrayList<DataJadwalDosen>model){
        inflater=LayoutInflater.from(context);
        this.context=context;
        this.model=model;
    }

    @Override
    public int getCount() {
        return model.size();
    }

    @Override
    public Object getItem(int position) {
        return model.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    TextView jam_kuliah, nama_matkul, semester;
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view=inflater.inflate(R.layout.list_data_jadwaladmin, parent, false);
        jam_kuliah=view.findViewById(R.id.jamKuliah);
        nama_matkul=view.findViewById(R.id.namaMatakuliah);
        semester=view.findViewById(R.id.semester);

        jam_kuliah.setText(model.get(position).getJam());
        nama_matkul.setText(model.get(position).getNama_matkul());
        semester.setText(model.get(position).getSemester());
        return view;
    }
}
