package com.idaoktavia.absensidosen;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class JadwalKuliah extends Activity{
    public String id_kar, id_dosen, id_matkul, semester, nama_kar, jumlah_sks, nama_matakuliah, alamat, jabatan, jam, hari, jam_kuliah, weekDay, tgl, deskripsi, waktu, kota, provinsi, kodepos, negara;
    TextView textNama, textJabatan, textLokasi, textJam, textHari;
    Spinner spinnerMatkul, spinnerHari, spinnerSemester, spinnerDosen, spinnerJamkul;
    protected LocationManager locationManager;
    protected LocationListener locationListener;
    List<Address> addresses;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int LOCATION_REQUEST_CODE = 1;
    Button simpan;
    RequestQueue requestQueue;
    Geocoder geocoder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //jendela tanpa title
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_jadwalkuliah);

        simpan = findViewById(R.id.buttonsimpan);


        Intent intent = getIntent();
        id_kar = intent.getStringExtra("id_karyawan");
        nama_kar = intent.getStringExtra("nama");
        jabatan = intent.getStringExtra("jabatan");

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyy");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        if (weekDay.equals("Monday")) {
            weekDay = "Senin";
        } else if (weekDay.equals("Tuesday")) {
            weekDay = "Selasa";
        } else if (weekDay.equals("Wednesday")) {
            weekDay = "Rabu";
        } else if (weekDay.equals("Thursday")) {
            weekDay = "Kamis";
        } else if (weekDay.equals("Friday")) {
            weekDay = "Jum'at";
        } else if (weekDay.equals("Saturday")) {
            weekDay = "Sabtu";
        } else if (weekDay.equals("Sunday")) {
            weekDay = "Minggu";
        }
        jam = sdf.format(new Date());
        spinnerMatkul = (Spinner) findViewById(R.id.pilihMatakuliah);
        ArrayAdapter<String> adapterMatkul = new ArrayAdapter<String>(JadwalKuliah.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.matkul));
        adapterMatkul.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMatkul.setAdapter(adapterMatkul);
        spinnerMatkul.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                id_matkul=String.valueOf(adapterView.getSelectedItemId());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerHari = (Spinner) findViewById(R.id.pilihHari);
        ArrayAdapter<String> adapterHari = new ArrayAdapter<String>(JadwalKuliah.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.hari));
        adapterHari.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerHari.setAdapter(adapterHari);
        spinnerHari.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                hari=adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinnerJamkul = (Spinner) findViewById(R.id.pilihJam);
        ArrayAdapter<String> adapterJamkul = new ArrayAdapter<String>(JadwalKuliah.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.jamkul));
        adapterJamkul.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerJamkul.setAdapter(adapterJamkul);
        spinnerJamkul.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                jam_kuliah=adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerSemester = (Spinner) findViewById(R.id.pilihSemester);
        ArrayAdapter<String> adapterSemester = new ArrayAdapter<String>(JadwalKuliah.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.semester));
        adapterSemester.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSemester.setAdapter(adapterSemester);
        spinnerSemester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                semester=adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerDosen = (Spinner) findViewById(R.id.pilihDosen);
        ArrayAdapter<String> adapterDosen = new ArrayAdapter<String>(JadwalKuliah.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.statuskar));
        adapterDosen.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDosen.setAdapter(adapterDosen);
        spinnerDosen.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                id_dosen=adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        clickSimpan();
    }

    @SuppressLint("MissingPermission")
    private void getCurrentLocation() {
        LocationRequest locationRequest=new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(2000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationServices.getFusedLocationProviderClient(JadwalKuliah.this).
                requestLocationUpdates( locationRequest, new LocationCallback(){
                    @Override
                    public void onLocationResult(@NonNull @NotNull LocationResult locationResult) {
                        super.onLocationResult(locationResult);
                        LocationServices.getFusedLocationProviderClient(JadwalKuliah.this)
                                .removeLocationUpdates(this);
                        if(locationResult!=null && locationResult.getLocations().size()>0){
                            int latestLocationIndex=locationResult.getLocations().size()-1;
                            double latitude=locationResult.getLocations().get(latestLocationIndex).getLatitude();
                            double longitude=locationResult.getLocations().get(latestLocationIndex).getLongitude();
                            //textLokasi.setText("Lokasi Absen: "+ String.format(latitude+" "+longitude));
                            geocoder= new Geocoder(JadwalKuliah.this, Locale.getDefault());
                            try {
                                addresses = geocoder.getFromLocation(latitude, longitude, 1);
                                alamat = addresses.get(0).getAddressLine(0);
                                kota = addresses.get(0).getLocality();
                                provinsi = addresses.get(0).getAdminArea();
                                negara = addresses.get(0).getCountryName();
                                kodepos = addresses.get(0).getPostalCode();
                                //knonName = addresses.get(0).getFeatureName();
                                textLokasi.setText("Lokasi Absen: "+kota);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, Looper.getMainLooper());
    }

    private void askLocationPermission() {
        if (ActivityCompat.checkSelfPermission(JadwalKuliah.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(JadwalKuliah.this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(JadwalKuliah.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(JadwalKuliah.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                getCurrentLocation();
            } else {
                //Permission not granted
            }
        }
    }

    public void clickSimpan() {
        simpan = (Button) findViewById(R.id.buttonsimpan);
        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_data();
            }
        });
    }
    void input_data(){
        String url = "https://presensidosen.000webhostapp.com/admin/tambah_jadwal.php";
        StringRequest response = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Intent i = new Intent(JadwalKuliah.this, HomeAdmin.class);
                        startActivity(i);
                    }
                },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                SimpleDateFormat sdfTgl = new SimpleDateFormat("dd-MM-yyy");
                tgl=sdfTgl.format(new Date());
                SimpleDateFormat sdfJam = new SimpleDateFormat("HH:mm:ss z");
                waktu=sdfJam.format(new Date());
                Map <String, String> form = new HashMap<>();
                form.put("id_matkul", id_matkul);
                form.put("hari", hari);
                form.put("jam", jam_kuliah);
                form.put("semester",semester);
                form.put("id_dosen",id_dosen);
                return form;
            }
        };
        requestQueue = Volley.newRequestQueue(JadwalKuliah.this);
        Toast.makeText(getApplicationContext(),id_matkul+", "+hari+", "+jam_kuliah+", "+semester+", "+id_dosen, Toast.LENGTH_LONG).show();
        requestQueue.add(response);
    }
}
