package com.idaoktavia.absensidosen;

public class DataMataKuliah {
    String id_matkul, nama_matkul, jumlahsks;
    public DataMataKuliah(String id_matkul, String nama_matkul, String jumlahsks){
        this.id_matkul=id_matkul;
        this.nama_matkul=nama_matkul;
        this.jumlahsks=jumlahsks;
    }
    public DataMataKuliah(String id_matkul, String nama_matkul){
        this.id_matkul=id_matkul;
        this.nama_matkul=nama_matkul;
    }
    //    public DataLaporan(String id_kar, String nama_kar, String tgl, String keterangan,
//                       String jam_masuk, String lokasi_mas, String lokasi_pul,
//                       String deskripsi, String jam_pulang){
//                    this.id_kar=id_kar;
//                    this.nama_kar=nama_kar;
//                    this.tgl=tgl;
//                    this.keterangan=keterangan;
//                    this.jam_masuk=jam_masuk;
//                    this.lokasi_mas=lokasi_mas;
//                    this.lokasi_pul=lokasi_pul;
//                    this.deskripsi=deskripsi;
//                    this.jam_pulang=jam_pulang;
//    }
    public String getId_matkul(){
        return id_matkul;
    }
    public String getNama_matkul(){ return nama_matkul;}
    public String getJumlahsks(){return jumlahsks;}


}

